<?php

namespace Mpdf\Tag;

class B extends InlineTag
{


}
