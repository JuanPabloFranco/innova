<?php

namespace Mpdf\Tag;

class FigCaption extends BlockTag
{


}
