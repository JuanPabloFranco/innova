<?php

namespace Mpdf\Container;

class NotFoundException extends \Mpdf\MpdfException
{

}
